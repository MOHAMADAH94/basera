from django.contrib import admin
from .models import Quiz, Question, Choice, QuizAttempt, Answer


class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 2
    fields = ['choice_text', 'is_correct']


class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1
    fields = ['question_type', 'question_text', 'question_audio', 'order', 'points']
    show_change_link = True


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ['title', 'lesson', 'passing_score', 'questions_count', 'created_at']
    list_filter = ['created_at', 'lesson__category', 'lesson']
    search_fields = ['title', 'description', 'lesson__title']
    inlines = [QuestionInline]
    fieldsets = (
        ('المعلومات الأساسية', {
            'fields': ('lesson', 'title', 'description', 'passing_score'),
            'description': (
                'هذه الاختبارات هي التي تظهر في تطبيق بصيرة. '
                'اربط الاختبار بدرس منشور، ثم أضف الأسئلة والخيارات.'
            ),
        }),
    )

    @admin.display(description='عدد الأسئلة')
    def questions_count(self, obj):
        return obj.questions.count()


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['question_text_short', 'quiz', 'question_type', 'points', 'order']
    list_filter = ['question_type', 'quiz']
    search_fields = ['question_text', 'quiz__title']
    inlines = [ChoiceInline]
    ordering = ['quiz', 'order']
    autocomplete_fields = ['quiz']

    @admin.display(description='نص السؤال')
    def question_text_short(self, obj):
        text = obj.question_text or ''
        return text[:70] + ('…' if len(text) > 70 else '')

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        self._ensure_true_false_choices(obj)

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        self._ensure_true_false_choices(form.instance)

    def _ensure_true_false_choices(self, question):
        if question.question_type != 'true_false':
            return
        if question.choices.exists():
            return
        Choice.objects.create(question=question, choice_text='صح', is_correct=True)
        Choice.objects.create(question=question, choice_text='خطأ', is_correct=False)


@admin.register(QuizAttempt)
class QuizAttemptAdmin(admin.ModelAdmin):
    list_display = ['user', 'quiz', 'score', 'passed', 'started_at', 'completed_at']
    list_filter = ['passed', 'started_at', 'quiz']
    search_fields = ['user__username', 'quiz__title']
    readonly_fields = ['started_at', 'completed_at']


@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['attempt', 'question', 'is_correct', 'points_earned', 'reviewed']
    list_filter = ['is_correct', 'reviewed']
    search_fields = ['attempt__user__username', 'question__question_text']
