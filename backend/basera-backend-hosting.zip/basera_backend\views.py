from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response


def home(request):
    """صفحة جذر الباك اند — روابط سريعة بدل 404."""
    return render(request, 'home.html', {
        'admin_url': '/admin/',
        'api_url': '/api/',
        'front_hint': 'http://127.0.0.1:5500/',
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def api_root(request):
    """فهرس واجهات API."""
    base = request.build_absolute_uri('/').rstrip('/')
    return Response({
        'name': 'بصيرة API',
        'status': 'ok',
        'endpoints': {
            'auth': f'{base}/api/auth/',
            'login': f'{base}/api/auth/login/',
            'register': f'{base}/api/auth/register/',
            'lessons': f'{base}/api/lessons/lessons/',
            'grades': f'{base}/api/lessons/grades/',
            'categories': f'{base}/api/lessons/categories/',
            'tests': f'{base}/api/tests/',
            'volunteers': f'{base}/api/volunteers/',
            'admin': f'{base}/admin/',
        },
        'note': 'افتح /admin/ للوحة التحكم. موقع نبض الفرونت يُشغَّل عبر start.bat من جذر المشروع على المنفذ 5500.',
    })
