(function () {
  'use strict';

  document.documentElement.classList.add('basera-admin');

  function ensureRtl() {
    var lang = (document.documentElement.lang || '').toLowerCase();
    if (lang.indexOf('ar') === 0 || document.body.classList.contains('rtl')) {
      document.documentElement.setAttribute('dir', 'rtl');
    }
  }

  function enhanceSelects(root) {
    var scope = root || document;
    var selects = scope.querySelectorAll('select');
    selects.forEach(function (el) {
      if (el.dataset.baseraSelectReady === '1') return;
      el.dataset.baseraSelectReady = '1';
      el.classList.add('basera-select');
      // ضمان ظهور القيمة الحالية بوضوح عند التركيز
      el.addEventListener('focus', function () {
        el.style.outline = 'none';
      });
    });
  }

  function enhanceNavFilter() {
    var navFilter = document.getElementById('nav-filter');
    if (navFilter && !navFilter.getAttribute('placeholder')) {
      navFilter.setAttribute('placeholder', 'بحث في القوائم…');
    }
  }

  function boot() {
    ensureRtl();
    enhanceNavFilter();
    enhanceSelects(document);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // بعد تهيئة autocomplete/select2 في Django
  document.addEventListener('formset:added', function (e) {
    enhanceSelects(e.target || document);
  });

  // راقب العناصر المضافة ديناميكياً (Select2)
  if (window.MutationObserver) {
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes.forEach(function (node) {
          if (node.nodeType === 1) enhanceSelects(node);
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }
})();
