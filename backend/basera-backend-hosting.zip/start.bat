@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Basera Backend فقط

cd /d "%~dp0"

echo.
echo ========================================
echo   بصيرة - تشغيل الباك اند فقط
echo ========================================
echo.
echo   للتشغيل الكامل (فرونت + باك) استخدم:
echo   ..\start.bat
echo.

set "URL_HOME=http://127.0.0.1:8000/"
set "URL_ADMIN=http://127.0.0.1:8000/admin/"
set "URL_API=http://127.0.0.1:8000/api/"

if not exist "manage.py" (
  echo [خطأ] ضع هذا الملف داخل مجلد backend
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" (
  echo [!] إنشاء venv...
  py -3.10 -m venv venv 2>nul
  if not exist "venv\Scripts\python.exe" py -3 -m venv venv 2>nul
  if not exist "venv\Scripts\python.exe" python -m venv venv 2>nul
  if not exist "venv\Scripts\python.exe" (
    echo [خطأ] تعذر إنشاء venv
    pause
    exit /b 1
  )
)

set "PYTHON=venv\Scripts\python.exe"
set "PIP=venv\Scripts\pip.exe"

"%PYTHON%" -c "import django" 2>nul
if errorlevel 1 (
  if exist "requirements.txt" (
    "%PIP%" install -r requirements.txt
  ) else (
    "%PIP%" install "Django>=4.2,<5" djangorestframework django-cors-headers django-filter python-decouple python-dotenv Pillow pdfplumber PyPDF2 gTTS
  )
)

if not exist "media\lessons\audio" mkdir "media\lessons\audio"
if not exist "media\lessons\pdf" mkdir "media\lessons\pdf"
if not exist "media\questions\audio" mkdir "media\questions\audio"
if not exist "staticfiles" mkdir "staticfiles"
if not exist "tmp" mkdir "tmp"
if not exist "static" mkdir "static"
if not exist ".env" (
  echo DEBUG=True> .env
  echo ENABLE_SERVER_TTS=True>> .env
)

"%PYTHON%" manage.py migrate --noinput
if errorlevel 1 (
  echo [خطأ] فشل migrate
  pause
  exit /b 1
)

"%PYTHON%" manage.py check
if errorlevel 1 (
  echo [خطأ] فشل الفحص
  pause
  exit /b 1
)

echo.
echo   Admin : %URL_ADMIN%
echo   Home  : %URL_HOME%
echo   API   : %URL_API%
echo.
echo فتح الروابط في المتصفح...
start "" "%URL_HOME%"
timeout /t 1 /nobreak >nul
start "" "%URL_ADMIN%"
timeout /t 1 /nobreak >nul
start "" "%URL_API%"

echo.
echo   للإيقاف: Ctrl+C
echo.

"%PYTHON%" manage.py runserver 127.0.0.1:8000
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo [!] توقف برمز %EXITCODE%
  pause
)
exit /b %EXITCODE%
